


<?php $__env->startSection('content'); ?>



<h3>Listando os clientes cadastrados</h3>
<hr>

<table border="1">

<tr>
    <th>Nome</th>
    <th>Cidade</th>
    <th>E-mail</th>
    <th colspan="3">Comandos</th>
</tr>
<?php if(@isset($clients)): ?>
 <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr>
         <td><?php echo e($client->name); ?></td>
         <td><?php echo e($client->city); ?></td>
         <td><?php echo e($client->email); ?></td>
         <td><a href="<?php echo e(route('client.show', $client->id)); ?>">Exibir</a></td>
         <td><a href="<?php echo e(route('client.edit', $client->id)); ?>">Editar</a></td>
         <td>
             <form method="POST" action="<?php echo e(route ('client.destroy', $client->id)); ?>">
             <?php echo csrf_field(); ?>
             <?php echo method_field('DELETE'); ?>
             <input type="submit" value="Excluir">
             </form>
         </td>
     </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<tr>
    <td colspan="4">Não há dados cadastrados!</td>
</tr>
</table>
<?php $__env->stopSection(); ?>

<?php endif; ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Aio\laravel\introlaravel\resources\views/client/index.blade.php ENDPATH**/ ?>