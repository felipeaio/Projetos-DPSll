

<?php $__env->startSection('content'); ?>
    
<form method="POST" action="<?php echo e(route('client.update', $client->id)); ?>">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
    <label for="name">Nome</label>
    <input type="text" name="name" maxlength="50" 
    required value ="<?php echo e($client -> name); ?>">
    <br>

    <label for="name">Cidade</label>
    <input type="text" name="city" maxlength="50" 
    required value ="<?php echo e($client -> city); ?>">
    <br>

    <label for="name">E-mail</label>
    <input type="text" name="email" maxlength="50" 
    required value ="<?php echo e($client -> email); ?>">
    <br>

<input type="submit" value="Salvar">

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Aio\laravel\introlaravel\resources\views/client/edit.blade.php ENDPATH**/ ?>