<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intro Laravel</title>
</head>

<body>
    <div class="container">
        <header>
            <h1>Introdução ao Laravel</h1>
        </header>
        <nav>
            <h2>Cadastro de Cliente</h2>
            <ol>
                <li><a href="<?php echo e(route('client.index')); ?>">Inicio</a></li>
                <li><a href="<?php echo e(route('client.create')); ?>">Novo Cliente</a></li>
            </ol>
        </nav>
        <section>
            <?php echo $__env->yieldContent('content'); ?>
        </section>
        <footer>
            <small>Tecnologia em Sistema para Intenet</small>
        </footer>
    </div>
</body>

</html><?php /**PATH C:\Aio\laravel\introlaravel\resources\views/base.blade.php ENDPATH**/ ?>