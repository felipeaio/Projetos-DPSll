

<?php $__env->startSection('content'); ?>
    
<form method="POST" action="<?php echo e(route('client.store')); ?>">
    <?php echo csrf_field(); ?>
    <label for="name">Nome</label>
    <input type="text" name="name" maxlength="50" required>
    <br>

    <label for="name">Cidade</label>
    <input type="text" name="city" maxlength="50" required>
    <br>

    <label for="name">E-mail</label>
    <input type="text" name="email" maxlength="50" required>
    <br>

<input type="submit" value="Salvar">

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aluno\Desktop\introlaravel\resources\views/client/create.blade.php ENDPATH**/ ?>