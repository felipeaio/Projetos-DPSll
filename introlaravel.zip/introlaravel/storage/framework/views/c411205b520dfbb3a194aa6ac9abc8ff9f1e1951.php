<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Views</title>
</head>

<body>

    <h1>Lista de Produtos</h1>

    <?php if(isset($products)): ?>
    <ol>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($p); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
    <?php endif; ?>


</body>

</html><?php /**PATH C:\Users\Aluno\Documents\DDMI\introlaravel\introlaravel\resources\views/product.blade.php ENDPATH**/ ?>