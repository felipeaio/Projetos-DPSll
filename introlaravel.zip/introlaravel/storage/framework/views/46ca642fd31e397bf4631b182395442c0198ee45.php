

<?php $__env->startSection('content'); ?>

<h2>Visualizando dados do clientes</h2>

<p><strong>ID:</strong><?php echo e($client->id); ?></p>

<p><strong>Nome:</strong><?php echo e($client->name); ?></p>

<p><strong>Cidade:</strong><?php echo e($client->city); ?></p>

<p><strong>Email:</strong><?php echo e($client->email); ?></p>

<a href="<?php echo e(route('client.index')); ?>">Voltar</a>

<hr>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Aio\laravel\introlaravel\resources\views/client/show.blade.php ENDPATH**/ ?>