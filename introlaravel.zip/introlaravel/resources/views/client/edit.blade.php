@extends('base')

@section('content')
    
<form method="POST" action="{{ route('client.update', $client->id) }}">
    @method('PUT')
    @csrf
    <label for="name">Nome</label>
    <input type="text" name="name" maxlength="50" 
    required value ="{{ $client -> name}}">
    <br>

    <label for="name">Cidade</label>
    <input type="text" name="city" maxlength="50" 
    required value ="{{ $client -> city }}">
    <br>

    <label for="name">E-mail</label>
    <input type="text" name="email" maxlength="50" 
    required value ="{{ $client -> email }}">
    <br>

<input type="submit" value="Salvar">

</form>

@endsection
